/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg123220208;

import javax.swing.*;
import pack.animasii;
import pack.menulis;
/**
 *
 * @author LENOVO
 */
public class lomba {
    public static void main (String[] args) {
//        JFrame frame = new JFrame();
//        
//        frame.setTitle("Buat Frame"); //memberinama pada gui
//        frame.setSize(500, 600); //menentukan ukuran gui
//        frame.setLocationRelativeTo(null); //menentukan posisi pop up gui
//        frame.setVisible(true); //buat ngeluarin gui
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //buat ngehentiin program saat gui di close
        GUI g = new GUI();
    }
}

class GUI extends JFrame {
    JLabel ljenis = new JLabel("Jenis Lomba");
    JRadioButton rmenulis = new JRadioButton("Menulis Surat");
    JRadioButton ranimasi = new JRadioButton("Animasi");
    if (ljenis = 'rmenulis') {
    frame.pack();
    } else if (ljenis = animasi') {
    frame.pack();
}