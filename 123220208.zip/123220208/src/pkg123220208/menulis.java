/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg123220208;

import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
/**
 *
 * @author LENOVO
 */
public class menulis {
    public static void main (String[] args) {
        GUI g = new GUI();
    }
}

class GUI extends JFrame {
    JLabel lnama = new JLabel("Nama");
    JTextField fnama = new JTextField(20);
    JLabel lsekolah = new JLabel("Asal Sekolah");
    JTextField fsekolah = new JTextField(20);
    JLabel lpenilaian = new JLabel("Bobot Penilaian");
    JLabel lstruktur = new JLabel("Struktur Cerita    15%");
    JTextField fstruktur = new JTextField(20);
    JLabel lisi = new JLabel("Isi Surat      35%");
    JTextField fisi = new JTextField(20);
    JLabel lkreativitas = new JLabel("Kreativitas     35%");
    JTextField fkreativitas = new JTextField(20);
    JLabel lsinema = new JLabel("Penerapan Kaidah Bahasa  15%");
    JTextField fsinema = new JTextField(20);
    
 public GUI(){
        setSize(350, 200);
        
        setLayout(null); 
        
        add(lnama);
        add(fnama);
        add(lsekolah);
        add(fsekolah);
        add(lpenilaian);
        add(lstruktur);
        add(fstruktur);
        add(lisi);
        add(fisi);
        add(lkreativitas);
        add(fkreativitas);
        add(lsinema);
        add(fsinema);
        System.out.println("fstruktur" + "fisi" + "fkreativitas" + "fsinema");
        lnama.setBounds(10, 10, 120, 20); //angka pertama adalah x, kedua y, ketiga tinggi, keempat lebar
        fnama.setBounds(130, 10, 150, 20);
        lsekolah.setBounds(10, 35, 170, 20);
        fsekolah.setBounds(125, 35, 70, 20);
        lpenilaian.setBounds(200, 35, 100, 20);
        lstruktur.setBounds(10, 60, 150, 20);
        fstruktur.setBounds(130, 60, 150, 20);
        lisi.setBounds(10, 85, 120, 20);
        fisi.setBounds(125, 85, 100, 20);
        lkreativitas.setBounds(230, 85, 150, 20);
        fkreativitas.setBounds(100, 130, 120, 20);
        lsinema.setBounds(100, 130, 120, 20);
        fsinema.setBounds(100, 130, 120, 20);
        
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
}